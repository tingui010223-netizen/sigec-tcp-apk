# SIGEC Almacén — proyecto Android

Este proyecto envuelve la aplicación HTML existente usando Capacitor y contiene un flujo de GitHub Actions para compilar una APK de depuración.

## Compilación automática
1. Sube el contenido de esta carpeta a la raíz de un repositorio GitHub.
2. Abre la pestaña **Actions** y ejecuta **Construir APK Android** (o haz un push a `main`).
3. Cuando termine, abre la ejecución y descarga el artefacto `sigec-almacen-debug-apk`.
4. Dentro estará `app-debug.apk`, instalable para pruebas.

## Importante
- Esta es una APK de depuración, no una versión firmada para distribución comercial.
- No se ha ejecutado una compilación Android en este entorno. El flujo debe ejecutarse en GitHub Actions para confirmar que compila.
- La aplicación sigue guardando sus datos en el almacenamiento local del WebView. Desinstalar la app o borrar sus datos puede eliminar el inventario; exporta copias de seguridad.
- La generación de etiquetas de código de barras depende de JsBarcode cargado desde jsDelivr, por lo que esa función puede no funcionar sin Internet. ExcelJS sí está embebido en el HTML.
- Antes de usarla en un negocio real, hay que probar los cálculos, fechas, importación/exportación, cierres y permisos en Android.
